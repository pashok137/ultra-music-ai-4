ULTRA MUSIC AI – Android APK Project (v0.4)

यह Android WebView प्रोजेक्ट है। इसमें मोबाइल के लिए ULTRA MUSIC AI Prompt Studio शामिल है।

अभी उपलब्ध सुविधाएँ:
- अलग Lyrics Prompt और Music Prompt
- 1 से 8 मिनट तक अवधि चयन
- भजन, मंत्र/स्तोत्र, ग़ज़ल, रोमांटिक, क्लासिकल, लोकगीत, DJ EDM आदि
- पुरुष / महिला / युगल आवाज़ चयन
- मुखड़ा बार-बार दोहराने और लय-ताल बनाए रखने के निर्देश
- Prompt कॉपी करना और TXT डाउनलोड करना
- Android APK बनाने के लिए GitHub Actions workflow

महत्वपूर्ण सीमा:
यह v0.4 अभी Prompt Generator APK project है, Suno जैसा असली AI singing/audio engine नहीं। इससे अभी MP3 गीत generate नहीं होता। असली गायन + संगीत + MP3 के लिए सुरक्षित server-side AI audio API जोड़नी होगी। API key को Android ऐप या public GitHub code में नहीं रखना है। किसी API की free quota/कीमत बदल सकती है; unlimited free generation की गारंटी नहीं है।

Android मोबाइल से APK बनाने के चरण:
1. ZIP को फोन में डाउनलोड करके Extract करें।
2. GitHub में अपना repository खोलें (उदाहरण: ultra-music-ai-4)।
3. Add file > Upload files चुनें। Extract किए गए project के अंदर की सभी files/folders upload करें; ZIP को सीधे upload न करें।
4. Commit changes करें।
5. Actions tab खोलें।
6. “Build ULTRA MUSIC AI APK” workflow चुनें और Run workflow दबाएँ।
7. Build सफल होने पर workflow run खोलें। नीचे Artifacts में ULTRA-MUSIC-AI-debug-apk डाउनलोड करें।
8. डाउनलोड ZIP को Extract करें और app-debug.apk पर टैप करके install करें। Android में अनुमति माँगे तो केवल अपने बनाए APK के लिए install permission दें।

यदि Actions में workflow न दिखे, जाँचें कि .github/workflows/build-apk.yml भी repository में upload हुआ है।

अगला विकास चरण: सुरक्षित backend + चुनी हुई AI music API + job status + MP3 download + song library।
